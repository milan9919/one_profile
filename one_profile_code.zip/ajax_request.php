<?php
include("config.php");

extract($_POST);

if (isset($_POST['action']) and $_POST['action'] == "saveStep1") {

    extract($_REQUEST);
    
    $user_id = $_SESSION['userData']['id'];
    
    if(!empty($_POST['creator'])){
        foreach($_POST['creator'] as $tag_id){
            $res = $db->pdoQuery("SELECT * FROM tbl_user_tags WHERE user_id = '".$user_id."' AND tag_id = '". $tag_id."'")->result();

            if(empty($res)){
                $insert_array = array(
                    "user_id" => $user_id,
                    "tag_id"    => $tag_id
                );
                
                $db->insert("tbl_user_tags", $insert_array)->lastInsertId();
            }
        }    
    }
    
    if(!empty($_POST['category'])){
        foreach($_POST['category'] as $tag_id){
            $res = $db->pdoQuery("SELECT * FROM tbl_user_tags WHERE user_id = '".$user_id."' AND tag_id = '". $tag_id."'")->result();

            if(empty($res)){
                $insert_array = array(
                    "user_id" => $user_id,
                    "tag_id"    => $tag_id
                );
                
                $db->insert("tbl_user_tags", $insert_array)->lastInsertId();
            }
        }    
    }
    $update_array = array("step" => 1);
    
    $db->update("tbl_users",$update_array,array("id"=>$user_id));
    
    $responce = array('status' => 1, "message" => "Saved successfully.");

    echo json_encode($responce);
    exit;		
}

if (isset($_POST['action']) and $_POST['action'] == "saveStep2") {
    extract($_REQUEST);
    
    $user_id = $_SESSION['userData']['id'];
    
    $update_array = array("step" => 2, "about_me" => $_POST['about_me']);
    
    $db->update("tbl_users",$update_array,array("id"=>$user_id));
    
    $responce = array('status' => 1, "message" => "Saved successfully.");

    echo json_encode($responce);
    exit;		
}

if (isset($_POST['action']) and $_POST['action'] == "saveStep3") {
    extract($_REQUEST);
    
    $user_id = $_SESSION['userData']['id'];
    
    $update_array = array("step" => 3, "introduction_video_link" => $_POST['link']);
    
    $db->update("tbl_users",$update_array,array("id"=>$user_id));
    
    $responce = array('status' => 1, "message" => "Saved successfully.");

    echo json_encode($responce);
    exit;		
}

if (isset($_POST['action']) and $_POST['action'] == "saveStep4") {
    extract($_REQUEST);
    
    $user_id = $_SESSION['userData']['id'];
    
    $update_array = array("step" => 4);
    
    $db->update("tbl_users",$update_array,array("id"=>$user_id));
    
    $responce = array('status' => 1, "message" => "Saved successfully.");

    echo json_encode($responce);
    exit;		
}

if (isset($_POST['action']) and $_POST['action'] == "saveStep5") {
    extract($_REQUEST);
    
    $user_id = $_SESSION['userData']['id'];
    
    if(!empty($_POST['x_years'])){
        foreach($_POST['x_years'] as $tag_id){
            $res = $db->pdoQuery("SELECT * FROM tbl_user_tags WHERE user_id = '".$user_id."' AND tag_id = '". $tag_id."'")->result();

            if(empty($res)){
                $insert_array = array(
                    "user_id" => $user_id,
                    "tag_id"    => $tag_id
                );
                
                $db->insert("tbl_user_tags", $insert_array)->lastInsertId();
            }
        }    
    }
    
    $update_array = array("step" => 5, "availability" => $_POST['availability']);
    
    $db->update("tbl_users",$update_array,array("id"=>$user_id));
    
    $responce = array('status' => 1, "message" => "Saved successfully.");

    echo json_encode($responce);
    exit;		
}

if (isset($_POST['action']) and $_POST['action'] == "saveStep6") {
    extract($_REQUEST);
    
    $user_id = $_SESSION['userData']['id'];
        
    
    $archive_revenue_array = $_POST['archive_revenue'];
    
    if(!empty($archive_revenue_array)){
        foreach($archive_revenue_array as $i => $archive_revenue){
            if($archive_revenue != "" && $position != ""){
                $position = isset($_POST['position'][$i]) ? $_POST['position'][$i] : "";
                $start_date = isset($_POST['start_date'][$i]) ? $_POST['start_date'][$i] : "";
                $end_date = isset($_POST['end_date'][$i]) ? $_POST['end_date'][$i] : "";
                $status = isset($_POST['status_'.($i+1)]) ? 'complete' : 'ongoing';
                    
                $no_of_objective = isset($_POST['no_of_objective'][$i]) ? $_POST['no_of_objective'][$i] : "";
                
                $insert_array = array(
                    "user_id"   => $user_id,
                    "archive_revenue"    => $archive_revenue,
                    "position"    => $position,
                    "start_date"    => $start_date,
                    "end_date"    => $end_date,
                    "status"    => $status
                );
                
                if(isset($_FILES['image_'.($i+1)]['name']) && $_FILES['image_'.($i+1)]['name'] != ""){
                    $name = "objectives-".time();
            		$target_dir = DIR_UPD. "user/";
            		$target_file = $target_dir .$name."-".$_FILES['image_'.($i+1)]["name"];
            		move_uploaded_file($_FILES['image_'.($i+1)]["tmp_name"], $target_file);
            		$image = $name."-".$_FILES['image_'.($i+1)]["name"];
            		$insert_array['image'] = $image;
                }
                
                $objective_id = $db->insert("tbl_user_objectives", $insert_array)->lastInsertId();
                
                if($no_of_objective != ""){
                    $quarterly_revenues = isset($_POST['quarterly_revenue_'.$no_of_objective]) ? $_POST['quarterly_revenue_'.$no_of_objective] : [];
                    
                    if(!empty($quarterly_revenues)){
                        foreach($quarterly_revenues as $j => $quarterly_revenue){
                            if($quarterly_revenue != ""){
                                $description = isset($_POST['description_'.$no_of_objective][$j]) ? $_POST['description_'.$no_of_objective][$j] : "";
                            
                                $insert_key_array = array(
                                    "objective_id"      => $objective_id,
                                    "quarterly_revenue" => $quarterly_revenue,
                                    "description"       => $description
                                );
                                
                                $db->insert("tbl_user_key_results", $insert_key_array)->lastInsertId();
                            }
                        }
                    }
                }   
            }
        }    
    }
    
    $update_array = array("step" => '6');
    
    $db->update("tbl_users",$update_array,array("id"=>$user_id));
    
    $responce = array('status' => 1, "message" => "Saved successfully.");

    echo json_encode($responce);
    exit;		
}

if (isset($_POST['action']) and $_POST['action'] == "saveStep7") {
    extract($_REQUEST);
    
    $user_id = $_SESSION['userData']['id'];

    $update_array = array("step" => '7');
    
    $db->update("tbl_users",$update_array,array("id"=>$user_id));
    
    $responce = array('status' => 1, "message" => "Saved successfully.");

    echo json_encode($responce);
    exit;		
}   
?>
