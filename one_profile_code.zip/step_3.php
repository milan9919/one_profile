<?php
$page_title = 'Step 3';

include("header.php");
if (!isset($_SESSION['userData'])) {
    header("Location: ".SITE_URL);
}
?>
<style>
    @keyframes load {
        0% { width: 0; }
        100% { width: 30%; }
    }
</style>
<div class="container" style="margin-top: 30px;">
    <div class="row">
        <div class="col-lg-4"></div>
        <div class="col-12 col-lg-4">
            <div class="progress">
                <div class="progress-value"></div>
            </div>
        </div>
    </div>
</div>

<div class="container mt-3 mobile-hidden">
    <div class="row">
        <div class="col-12 col-lg-12 d-flex justify-content-center">
            <div class="number_circle">
                <div class="number"><p>3</p></div>
            </div>
            <div>
                <h4 class="text_blue">Give yourself a nice video introduction</h4>
                <p class="text_gray">Experts suggests that video can give a boost to your profile and you can <br> get noticed more</p>
            </div>
        </div>
    </div>
</div>


<div class="container mt-3 desktop-hidden">
    <div class="row">
        <div class="col-12 col-lg-12 d-flex justify-content-center desktop-hidden">
            <div class="number_circle_1">
                <div class="number_1"><p>3</p></div>
            </div>
            <div class="ml-2">
                <h4 class="text_blue mt-3">Give yourself a nice video introduction</h4>
                <p class="text_gray">Experts suggests that video can give a boost <br> to your profile and you can get noticed more</p>
                
            </div>
        </div>
    </div>
</div>


<div class="container">
    <div class="row">
        <div class="video col-12 col-lg-6">
            <div class="border_video">
                <div class="d-flex justify-content-center">
                    <i class="fa fa-play-circle video_circle" style="font-size:48px;color:rgb(255, 255, 255); position: absolute; "></i>
                    <img src="<?= SITE_IMG ?>shifaaz-shamoon-9K9ipjhDdks-unsplash 2.png" class="video_size" alt="">
                </div>
            </div>
        </div>
        <a href="https://www.mmhmm.app/home">
            <div class="video_1 col-12 col-lg-6" style="cursor: pointer;">
                <div class="video_line">
                    <p class="video_text">
                        You can create video for better impact using  
                    </p>
                    <a href="https://www.mmhmm.app/home " class="d-flex justify-content-center">
                        <img src="./assests/imgs/image 28.png" alt="">
                    </a>    
                </div>
            </div>
        </a>
    </div>
</div>

<div class="container" style="margin-bottom: 80px;">
    <div class="row">
        <div class="col-lg-3"></div>
        <div class="col-12 col-lg-6">
            <form action="">
                <input type="text" class="mt-5" id="introduction_video_link" name="introduction_video_link" placeholder="https://">
                <div style="color:red;" id="video_link_error"></div>
                <button type="button" class="button4 mt-4" onclick="check_step_three()" id="step3btn">Ok</button>
            </form>
        </div>
    </div>
</div>

<?php include("footer.php"); ?>
